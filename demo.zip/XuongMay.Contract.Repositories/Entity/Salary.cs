﻿using XuongMay.Core.Base;

namespace XuongMay.Contract.Repositories.Entity
{
    public class Salary : BaseEntity
    {

    }
}
