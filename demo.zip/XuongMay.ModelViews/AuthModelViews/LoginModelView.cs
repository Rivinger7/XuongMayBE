﻿namespace XuongMay.ModelViews.AuthModelViews
{
    public class LoginModelView
    {
        public required string Username { get; set; }
        public required string Password { get; set; }
    }
}
