﻿namespace XuongMay.ModelViews.UserModelViews
{
    public class UserResponseModel
    {
        public string? Id { get; set; }
    }
}
